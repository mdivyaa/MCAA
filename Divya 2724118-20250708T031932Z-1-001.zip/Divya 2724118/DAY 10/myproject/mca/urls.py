from django.urls import path
from.import views
urlpatterns=[
                 path('home/',views.home,name='home'),
                 path('dms/',views.dms,name='dms'),
                 path('java/',views.java,name='java'),
                 path('co/',views.co,name='co'),
                 path('os/',views.os,name='os'),
                 path('afm/',views.afm,name='afm'),
                 path('javalab/',views.javalab,name='javalab'),
                 path('oslab/',views.oslab,name='oslab'),
                 path('swlab/',views.swlab,name='swlab'),
                 path('coor/',views.coor,name='coor'),
                 path('javads/',views.javads,name='javads'),
                 path('dccn/',views.dccn,name='dccn'),
                 path('adbms/',views.adbms,name='adbms'),
                 path('ecommerce/',views.ecommerce,name='ecommerce'),
                 path('gd/',views.gd,name='gd'),
                 path('javadslab/',views.javadslab,name='javadslab'),
                 path('dccnlab/',views.dccnlab,name='dccnlab'),
                 path('adbmslab/',views.adbmslab,name='adbmslab'),
                  path('swtesting/',views.swtesting,name='swtesting'),
                 path('iot/',views.iot,name='iot'),
                 path('majorproject/',views.majorproject,name='majorproject'),
                 path('swengineering/',views.swengineering,name='swengineering'),
                 path('computertechnologies/',views.computertechnologies,name='computertechnologies'),
                 path('webtechnologies/',views.webtechnologies,name='webtechnologies'),
                 path('systemprogramming/',views.systemprogramming,name='systemprogramming'),
                 path('mobiledevelopment/',views.mobiledevelopment,name='mobiledevelopment'),
                 path('swlab3/',views.swlab3,name='swlab3'),
                 path('technicalseminar/',views.technicalseminar,name='technicalseminar'),
                  path('webtechnologieslab/',views.webtechnologieslab,name='webtechnologieslab'),
                 path('minorproject/',views.minorproject,name='minorproject'),
                 
                 
                 
]  



