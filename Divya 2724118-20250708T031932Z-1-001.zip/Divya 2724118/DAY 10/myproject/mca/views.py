from django.shortcuts import render
def home(request):
     return render(request,'homess.html')
def dms(request):
     return render(request,'dms.html')
def java(request):
     return render(request,'java.html')
def co(request):
     return render(request,'co.html')
def os(request):
     return render(request,'os.html')
def afm(request):
     return render(request,'afm.html')
def swlab(request):
     return render(request,'swlab.html')
def javalab(request):
     return render(request,'javalab.html')
def oslab(request):
     return render(request,'oslab.html')
def coor(request):
     return render(request,'coor.html')
def dccn(request):
     return render(request,'dccn.html')
def javads(request):
     return render(request,'javads.html')
def adbms(request):
     return render(request,'adbms.html')
def ecommerce(request):
     return render(request,'ecommerce.html')
def gd(request):
     return render(request,'gd.html')
def adbmslab(request):
     return render(request,'adbmslab.html')
def javadslab(request):
     return render(request,'javadslab.html')
def dccnlab(request):
     return render(request,'dccnlab.html')
def swtesting(request):
     return render(request,'swtesting.html')
def iot(request):
     return render(request,'iot.html')
def majorproject(request):
     return render(request,'majorproject.html')
def swengineering(request):
     return render(request,'swengineering.html')
def computertechnologies(request):
     return render(request,'computertechnologies.html')
def webtechnologies(request):
     return render(request,'webtechnologies.html')
def systemprogramming(request):
     return render(request,'systemprogramming.html')
def mobiledevelopment(request):
     return render(request,'mobiledevelopment.html')
def swlab3(request):
     return render(request,'swlab3.html')
def technicalseminar(request):
     return render(request,'technicalseminar.html')
def webtechnologieslab(request):
     return render(request,'webtechnologieslab.html')
def minorproject(request):
     return render(request,'minorproject.html')




# Create your views here.
