from django.contrib import admin
from .models import EmployeeModel
admin.site.register(EmployeeModel)
