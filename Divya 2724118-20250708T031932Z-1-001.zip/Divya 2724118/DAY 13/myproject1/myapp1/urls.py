from django.urls import path
from . import views
urlpatterns = [
   path('insert_employee1/',views.insert_employee1,name='insert_employee1'),
    # other paths as needed
]