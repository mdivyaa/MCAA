from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# Registration View
def register(request):
    if request.method == 'POST':
        uname = request.POST['username']
        email = request.POST['email']
        pwd = request.POST['password']

        if User.objects.filter(username=uname).exists():
            messages.error(request, 'Username already exists.')
            return redirect('register')

        user = User.objects.create_user(username=uname, email=email, password=pwd)  # Use create_user for hashed passwords
        messages.success(request, 'Registration successful. You can now log in.')
        return redirect('login')

    return render(request, 'register.html')

# Login View
def user_login(request):
    if request.method == 'POST':
        uname = request.POST['username']
        pwd = request.POST['password']
        user = authenticate(username=uname, password=pwd)  # Use Django's authenticate method

        if user:
            login(request, user)  # Log in the user
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials.')
            return redirect('login')

    return render(request, 'login.html')

# Logout View
def user_logout(request):
    logout(request)  # Log out the user
    return redirect('login')

# Home View (Protected)
@login_required(login_url='login')
def home(request):
    return render(request, 'home.html')

def home(request):
    return render(request,'home.html')
def mca101(request):
    return render(request, 'mca101.html')
def mca102(request):
    return render(request, 'mca102.html')
def menubar(request):
    return render(request, 'menubar.html')
def homess(request):
     return render(request,'homess.html')
def dms(request):
     return render(request,'dms.html')
def java(request):
     return render(request,'java.html')
def co(request):
     return render(request,'co.html')
def os(request):
     return render(request,'os.html')
def afm(request):
     return render(request,'afm.html')
def swlab(request):
     return render(request,'swlab.html')
def javalab(request):
     return render(request,'javalab.html')
def oslab(request):
     return render(request,'oslab.html')
def coor(request):
     return render(request,'coor.html')
def dccn(request):
     return render(request,'dccn.html')
def javads(request):
     return render(request,'javads.html')
def adbms(request):
     return render(request,'adbms.html')
def ecommerce(request):
     return render(request,'ecommerce.html')
def gd(request):
     return render(request,'gd.html')
def adbmslab(request):
     return render(request,'adbmslab.html')
def javadslab(request):
     return render(request,'javadslab.html')
def dccnlab(request):
     return render(request,'dccnlab.html')
def swtesting(request):
     return render(request,'swtesting.html')
def iot(request):
     return render(request,'iot.html')
def majorproject(request):
     return render(request,'majorproject.html')
def swengineering(request):
     return render(request,'swengineering.html')
def computertechnologies(request):
     return render(request,'computertechnologies.html')
def webtechnologies(request):
     return render(request,'webtechnologies.html')
def systemprogramming(request):
     return render(request,'systemprogramming.html')
def mobiledevelopment(request):
     return render(request,'mobiledevelopment.html')
def swlab3(request):
     return render(request,'swlab3.html')
def technicalseminar(request):
     return render(request,'technicalseminar.html')
def webtechnologieslab(request):
     return render(request,'webtechnologieslab.html')
def minorproject(request):
     return render(request,'minorproject.html')
def project(request):
     return render(request,'project.html')