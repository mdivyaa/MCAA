from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
def day1(request):
     temp=loader.get_template('index.html')
     return HttpResponse(temp.render())
def day2(request):
      temp=loader.get_template('index2.html')
      return HttpResponse(temp.render())
def day3(request):
      temp=loader.get_template('index3.html')
      return HttpResponse(temp.render())
def day4(request):
     temp=loader.get_template('index4.html')
     return HttpResponse(temp.render())
def day5(request):
     temp=loader.get_template('index5.html')
     return HttpResponse(temp.render())
def day6(request):
      temp=loader.get_template('index6.html')
      return HttpResponse(temp.render())
def day7(request):
      temp=loader.get_template('index7.html')
      return HttpResponse(temp.render())
def day8(request):
      temp=loader.get_template('index8.html')
      return HttpResponse(temp.render())
def day9(request):
      temp=loader.get_template('index9.html')
      return HttpResponse(temp.render())
def day10(request):
     temp=loader.get_template('index10.html')
     return HttpResponse(temp.render())
def day11(request):
     temp=loader.get_template('index11.html')
     return HttpResponse(temp.render())
def day12(request):
     temp=loader.get_template('index12.html')
     return HttpResponse(temp.render())
def day13(request):
     temp=loader.get_template('index13.html')
     return HttpResponse(temp.render())
def day14(request):
     temp=loader.get_template('index14.html')
     return HttpResponse(temp.render())
def day15(request):
     temp=loader.get_template('index15.html')
     return HttpResponse(temp.render())

# Create your views here.
