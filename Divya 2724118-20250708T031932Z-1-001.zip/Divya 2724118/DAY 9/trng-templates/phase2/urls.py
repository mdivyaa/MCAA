from django.urls import path
from.import views
urlpatterns=[
           path('day16/',views.day16,name='day16'),
            path('day17/',views.day17,name='day17'),
            path('day18/',views.day18,name='day18'),
            path('day19/',views.day19,name='day19'),
             path('day20/',views.day20,name='day20'),
            path('day21/',views.day21,name='day21'),
            path('day22/',views.day22,name='day22'),
            path('day23/',views.day23,name='day23'),
            path('day24/',views.day24,name='day24'),
            path('day25/',views.day25,name='day25'),
            path('day26/',views.day26,name='day26'),
            path('day27/',views.day27,name='day27'),
            path('day28/',views.day28,name='day28'),
            path('day29/',views.day29,name='day29'),
            path('day30/',views.day30,name='day30'),
            
             
             
]