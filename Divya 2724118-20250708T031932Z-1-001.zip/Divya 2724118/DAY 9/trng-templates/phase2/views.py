from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
def day16(request):
     temp=loader.get_template('index16.html')
     return HttpResponse(temp.render())
def day17(request):
      temp=loader.get_template('index17.html')
      return HttpResponse(temp.render())
def day18(request):
      temp=loader.get_template('index18.html')
      return HttpResponse(temp.render())
def day19(request):
     temp=loader.get_template('index19.html')
     return HttpResponse(temp.render())
def day20(request):
     temp=loader.get_template('index20.html')
     return HttpResponse(temp.render())
def day21(request):
      temp=loader.get_template('index21.html')
      return HttpResponse(temp.render())
def day22(request):
      temp=loader.get_template('index22.html')
      return HttpResponse(temp.render())
def day23(request):
      temp=loader.get_template('index23.html')
      return HttpResponse(temp.render())
def day24(request):
      temp=loader.get_template('index24.html')
      return HttpResponse(temp.render())
def day25(request):
     temp=loader.get_template('index25.html')
     return HttpResponse(temp.render())
def day26(request):
     temp=loader.get_template('index26.html')
     return HttpResponse(temp.render())
def day27(request):
     temp=loader.get_template('index27.html')
     return HttpResponse(temp.render())
def day28(request):
     temp=loader.get_template('index28.html')
     return HttpResponse(temp.render())
def day29(request):
     temp=loader.get_template('index29.html')
     return HttpResponse(temp.render())
def day30(request):
     temp=loader.get_template('index30.html')
     return HttpResponse(temp.render())

# Create your views here.
