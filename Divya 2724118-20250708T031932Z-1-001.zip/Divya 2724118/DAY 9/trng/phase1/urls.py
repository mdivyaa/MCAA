from django.urls import path
from.import views
urlpatterns=[
           path('day1/',views.day1,name='day1'),
            path('day2/',views.day2,name='day2'),
            path('day3/',views.day3,name='day3'),
            path('day4/',views.day4,name='day4'),
             path('day5/',views.day5,name='day5'),
            path('day6/',views.day6,name='day6'),
            path('day7/',views.day7,name='day7'),
            path('day8/',views.day8,name='day8'),
            path('day9/',views.day9,name='day9'),
            path('day10/',views.day10,name='day10'),
            path('day11/',views.day11,name='day11'),
            path('day12/',views.day12,name='day12'),
            path('day13/',views.day13,name='day13'),
            path('day14/',views.day14,name='day14'),
            path('day15/',views.day15,name='day15'),
            
             
             
]