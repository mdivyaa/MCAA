from django.shortcuts import render
from django.http import HttpResponse
def day1(request):
     return HttpResponse('<h1 align="center">Hello This is Day1 Of Second Phase Training in python!</h1>')
def day2(request):
     return HttpResponse('<h1 align="center">Hello This is Day2 Of Second Phase Training in python!</h1>')
def day3(request):
     return HttpResponse('<h1 align="center">Hello This is Day3 Of Second Phase Training in python!</h1>')
def day4(request):
     return HttpResponse('<h1 align="center">Hello This is Day4 Of Second Phase Training in python!</h1>')
def day5(request):
     return HttpResponse('<h1 align="center">Hello This is Day5 Of Second Phase Training in python!</h1>')
def day6(request):
     return HttpResponse('<h1 align="center">Hello This is Day6 Of Second Phase Training in python!</h1>')
def day7(request):
     return HttpResponse('<h1 align="center">Hello This is Day7 Of Second Phase Training in python!</h1>')
def day8(request):
     return HttpResponse('<h1 align="center">Hello This is Day8 Of Second Phase Training in python!</h1>')
def day9(request):
     return HttpResponse('<h1 align="center">Hello This is Day9 Of Second Phase Training in python!</h1>')
def day10(request):
     return HttpResponse('<h1 align="center">Hello This is Day10 Of Second Phase Training in python!</h1>')
def day11(request):
     return HttpResponse('<h1 align="center">Hello This is Day11 Of Second Phase Training in python!</h1>')
def day12(request):
     return HttpResponse('<h1 align="center">Hello This is Day12 Of Second Phase Training in python!</h1>')
def day13(request):
     return HttpResponse('<h1 align="center">Hello This is Day13 Of Second Phase Training in python!</h1>')
def day14(request):
     return HttpResponse('<h1 align="center">Hello This is Day14 Of Second Phase Training in python!</h1>')
def day15(request):
     return HttpResponse('<h1 align="center">Hello This is Day15 Of Second Phase Training in python!</h1>')


# Create your views here.
